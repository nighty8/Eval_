前置条件：
pip install transformers==4.49.0

运行时（指定一张卡）
model path路径放deepseek 7B的 deepseek-ai/DeepSeek-R1-Distill-Qwen-7B
model_path_2路径放deepseek 1.5B的 deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B
顺序不对也完蛋了

export CUDA_VISIBLE_DEVICES=2
python Aanother.py --model_path '/data01/public/sutiancheng/models/deepseek-7B/' --model_path_2 '/data01/public/sutiancheng/models/deepseek-1.5B/'
